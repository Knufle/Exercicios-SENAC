package lista1;

import java.util.Scanner;

public class Exercicio4 {

	public static void main(String[] args) {
		
		Scanner numeros = new Scanner(System.in);
		System.out.print("Digite os 10 numeros: ");
		
		double[] a;
		a = new double[n];
		
		int a = numeros.nextInt();
		
		int [] lista = new int[10];
		
		
	}
	
}
