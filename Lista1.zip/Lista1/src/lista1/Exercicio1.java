package lista1;

public class Exercicio1 {

	public static void main(String[] args) {
		
		boolean b = true;
		if (b)
			{
				System.out.println("Verdade!");
				System.out.println("b � true");
			}			
		else
			System.out.println("Falso!");
		
	}
	
}

/* erro foi que faltou a inser��o de {} 
para a condi��o do if por ser mais de uma linha*/