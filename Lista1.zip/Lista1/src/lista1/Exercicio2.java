package lista1;

public class Exercicio2 {

	public static void main(String[] args) {
		
		int a = 21;
		if (a == 42)
		System.out.println("O valor de a � 42");
		else
		System.out.println("O valor de a n�o � 42");
	}
	
}

/*erro foi que na condi��o if, estava descrito a = 42,
atribuindo 42 como valor de a, sendo que na verdade
o correto � a==42 indicando a condi��o de quando a for
igual a 42*/
