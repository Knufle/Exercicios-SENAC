package exemplosfacul;

public class Decisaoifelse {
	
	public static void main(String[] args) {
		
		//float notaEstudante = (float) 5.5;
		double notaEstudante = 5.5;
		
		if( notaEstudante >= 6 )
			System.out.println("Aluno aprovado!");
		else
			System.out.println("Aluno reprovado!");
		
	}

}
