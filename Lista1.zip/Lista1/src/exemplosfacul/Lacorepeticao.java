package exemplosfacul;

public class Lacorepeticao {
	
	public static void main(String[] args) {
		
		for(int i=1; i<=17; i++) {
			
			if( i%2 == 0 )
				System.out.printf("%d � par \n", i);
			else
				System.out.printf("%d � impar \n", i);
			
		}
		
	}

}
