package exemplosfacul;

public class Decisaoswitchcase {

	public static void main(String[] args) {
		
		String periodo = "manha";
		
		switch( periodo ) {
		
		case "manha": System.out.println("Ohayou"); break;
		case "tarde": System.out.println("Konnichiwa"); break;
		case "noite": System.out.println("Konbanwa"); break;
		
		}
		
	}
	
}
